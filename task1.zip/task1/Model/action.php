<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include("../Config/conn.php");

class action{

    public function data($thoughtBy, $projectName,$discussDate,$status){

    $obj = new connected();
    $query = $obj->dbConn->prepare("INSERT INTO `projectform` (`ThoughtBy`, `ProjectName`, `DiscussDate`, `Status`) 
    VALUES ('$thoughtBy', '$projectName', '$discussDate', '$status')");
    $query->execute();
    $_SESSION['msg']="Data Saved for $thoughtBy";
    $query = $obj->dbConn->prepare("SELECT * FROM `projectform`");
    $query->execute();

    $Alldata = $query->fetchAll(PDO::FETCH_ASSOC);  
 
   
    $_SESSION['data']=$Alldata;
   
    header("location:../index.php");
    }
    public function getrecord(){
        $conn = new connected();
        $query = $conn->dbConn->prepare("SELECT * FROM `projectform`");
        $query->execute();

        $Alldata = $query->fetchAll(PDO::FETCH_ASSOC);  
     
       
        return $Alldata ;
}
public function upd($data){
    $conn = new connected();
    $query = $conn->dbConn->prepare("UPDATE `projectform` SET `thoughtBy` = '$data[thoughtBy]', `projectName` = '$data[projectName]',
    `discussDate` = '$data[discussDate]',`status` = '$data[status]' WHERE `projectform`.`id` = '$data[id]'");
    $query->execute(); 
    $message="data is updated";
     $_SESSION['msg']=$message;
     header("location:../index.php");

    }
    public function pre($discussionPanel, $discussionDate,$decisionMade,$allocatedTo,$triggerDate,$endDate,$finalOutcome,$status,$project_id){
        $obj = new connected();
        $query = $obj->dbConn->prepare("INSERT INTO `newtable` (`Discussion Panel`, `Discussion Date`, `Decision Made`, `Allocated To`, `Trigger Date`, `End Date`, `Final Outcome`, `Status`, `projectid`, `createon`)
         VALUES ('$discussionPanel', '$discussionDate', '$decisionMade', '$allocatedTo', '$triggerDate', '$endDate', '$finalOutcome', '$status', '$project_id', now());");
        $query->execute();
        
        
}
}
?>