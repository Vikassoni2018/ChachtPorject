<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class connected{

    function __construct(){
        $this->dbHost="localhost";
        $this->dbName="task1";  
       $this->dbUser="root";    
         $this->dbPassword=""; 
        

         try{  
            $this->dbConn = new PDO("mysql:host=$this->dbHost;dbname=$this->dbName",$this->dbUser,$this->dbPassword);  
          } 

          catch(Exception $e){  
          Echo "Connection failed" . $e->getMessage();  
          }  
    }
}

?>