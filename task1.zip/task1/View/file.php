<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
      background-color: pink;
    }

    .container {
      max-width: 80%;
      margin: 0 auto;
      padding: 20px;
      background-color: #fff;
      box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
      border-radius: 5px;
      display: flex;
    }

    h2 {
      color: #333;
    }

    label {
      font-weight: bold;
      margin-right: 10px;
    }

    input[type="text"],
    input[type="date"],
    select,
    textarea {
      width: 100%;
      padding: 8px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 3px;
    }

    select {
      height: 34px;
    }

    textarea {
      resize: vertical;
    }

    input[type="submit"] {
      background-color: #007bff;
      color: #fff;
      border: none;
      border-radius: 3px;
      padding: 10px 20px;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background-color: #0056b3;
    }

    .div1,
    .div2 {
      width: 50%;
      padding: 10px;
      box-sizing: border-box;
    }

    .button-group {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
    }

    .button-group button {
      background-color: #007bff;
      color: #fff;
      border: none;
      border-radius: 3px;
      padding: 10px 20px;
      cursor: pointer;
    }
    h2 {
      color: #333;
      text-align: center;
    }

    .button-group button:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
<div class="button-group">
    <button type="button" onclick="addIndependent()">Add Independent</button>
  </div>
  <h2>Project Details</h2>
  <div class="container">
    <div class="div1">
      <form id="discussionForm" method="POST" action="../Controller/control.php">
        <label for="discussionPanel">Discussion Panel:</label>
        <input type="text" id="discussionPanel" name="discussionPanel" required>
        <label for="decisionMade">Decision Made:</label>
        <textarea id="decisionMade" name="decisionMade" rows="1" required></textarea>
        <label for="triggerDate">Trigger Date:</label>
        <input type="date" id="triggerDate" name="triggerDate" required>
        <label for="finalOutcome">Final Outcome:</label>
        <textarea id="finalOutcome" name="finalOutcome" rows="1" required></textarea>
        
      </div>
      
    <div class="div2">
      <label for="discussionDate">Discussion Date:</label>
      <input type="date" id="discussionDate" name="discussionDate" required><br>
      <label for="allocatedTo">Allocated To:</label>
      <input type="text" id="allocatedTo" name="allocatedTo" required><br>
      <label for="endDate">End Date:</label>
      <input type="date" id="endDate" name="endDate" required><br>
      <label for="status">Status:</label>
      <select id="status" name="status">
        <option value="active">Active</option>
        <option value="pending">Pending</option>
        <option value="archive">Archive</option>
        <option value="reject">Reject</option>
      </select><br>
      <?php
      $project_id = $_GET['id'];
      echo '<input type="hidden" name="project_id" value="' . $project_id . '">';
      ?>
      <input type="submit" name="save" value="Save"><br><br>
    </div>
  </div>


  </form>

  <div class="container" id="form-2" style="display:none">
    <div class="div1" >
      <form id="newdiv" class="hidden" method="POST" action="../Controller/control.php">
        <label for="discussionPanel">Discussion Panel:</label>
        <input type="text" id="discussionPanel" name="discussionPanel" required>
        <label for="decisionMade">Decision Made:</label>
        <textarea id="decisionMade" name="decisionMade" rows="1" required></textarea>
        <label for="triggerDate">Trigger Date:</label>
        <input type="date" id="triggerDate" name="triggerDate" required>
        <label for="finalOutcome">Final Outcome:</label>
        <textarea id="finalOutcome" name="finalOutcome" rows="1" required></textarea>
        <input type="submit" name="save" value="Save"><br><br>
      </div>
      
    <div class="div2" id="div2">
      <label for="discussionDate">Discussion Date:</label>
      <input type="date" id="discussionDate" name="discussionDate" required><br>
      <label for="allocatedTo">Allocated To:</label>
      <input type="text" id="allocatedTo" name="allocatedTo" required><br>
      <label for="endDate">End Date:</label>
      <input type="date" id="endDate" name="endDate" required><br>
      <label for="status">Status:</label>
      <select id="status" name="status">
        <option value="active">Active</option>
        <option value="pending">Pending</option>
        <option value="archive">Archive</option>
        <option value="reject">Reject</option>
      </select><br>
    </div>
  </div>


  </form>

  <script>
    function addIndependent() {
      var x = document.getElementById("form-2");
          if (x.style.display === "none") {
            x.style.display = "flex";
          } else {
            x.style.display = "none";
          }
    }
  </script>
</body>
</html>
