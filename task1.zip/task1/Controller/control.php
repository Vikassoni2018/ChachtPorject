<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("../Model/action.php");
// session_start();
class control{


    public function save(){

        if(isset($_POST['submit'])){
            $thoughtBy=$_POST['thoughtBy'];
            $projectName=$_POST['projectName'];
            $discussDate=$_POST['discussDate'];
            $status=$_POST['status'];
            
$obj1 = new action();
$obj1->data($thoughtBy, $projectName,$discussDate,$status);

        }
        if(isset($_POST["show"]))
        {
           
         $obj1 = new action(); 
         
         $Alldata = $obj1->getrecord();
         $_SESSION["data"] = $Alldata;
        
          
         header("location:../index.php");

    }
    if(isset($_POST["edit"])){
    $data = ["id"=>$_POST['id'], "thoughtBy"=>$_POST['thoughtBy'], "projectName"=>$_POST['projectName'],"discussDate"=>$_POST['discussDate'],"status"=>$_POST['status']];
    $obj1 = new action();

    $obj1->upd($data);
    }
    if(isset($_POST['save'])){
        $discussionPanel=$_POST['discussionPanel'];
        $discussionDate=$_POST['discussionDate'];
        $decisionMade=$_POST['decisionMade'];
        $allocatedTo=$_POST['allocatedTo'];
        $triggerDate=$_POST['triggerDate'];
        $endDate=$_POST['endDate'];
        $finalOutcome=$_POST['finalOutcome'];
        $status=$_POST['status'];
        $project_id=$_POST['project_id'];


        
$obj1 = new action();
$obj1->pre($discussionPanel, $discussionDate,$decisionMade,$allocatedTo,$triggerDate,$endDate,$finalOutcome,$status,$project_id);

    }
    }
}

$obj = new control();
$obj->save();


?>